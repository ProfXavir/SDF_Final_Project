package BankProject;

import java.util.Scanner;

import java.text.DecimalFormat;

public class Banking {
	
		//variables
		int balance;
		String customername;
		String customerID;
		
		//Class consructor
		Banking(String cname, String cid) {
			customername = cname;
			customerID = cid;
		}
		
		//deposit
		void deposit(int amount) {
			if (amount != 0) {
				balance = balance + amount;
			}
		}
		
		
		//withdraw
		void withdraw(int amount) {
			if (amount != 0) {
				balance = balance - amount;
			}
		}
		
		
		//menu
		void menu() {
			char option;
			Scanner Scan = new Scanner(System.in);
			System.out.println("Welcome, " + customername + "!");
			System.out.println("Your ID is: " + customerID);
			System.out.println("\n What would you like to do? \n");
			System.out.println("A. Check Balance \nB. Make a Deposit \nC. Make a Withdrawl \nD. Exit \n");
			
			do {
				System.out.println("\n Enter an option: ");
				char option1 = Scan.next().charAt(0);
				option = Character.toUpperCase(option1);
				
				switch(option) {
				//Case A : Check Balance
				case 'A':
					System.out.println("Balance = $" + balance);
					break;
				//Case B: Deposit
				case 'B':
					System.out.println("Enter an amount to deposit: ");
					int amount = Scan.nextInt();
					deposit(amount);
					break;
				//Case C: Withdraw
				case 'C':
					System.out.println("Enter amount to withdraw: ");
					int amount2 = Scan.nextInt();
					withdraw(amount2);
					break;
				//Case D: Exit
				case 'D':
					System.out.println("======================================");
					break;
				//default: invalid input
				default:
					System.out.println("Error: Invalid Input. Please enter A, B, C, D.");
					break;
				}
			} while(option != 'D');
			System.out.println("Thank you for banking with YearUp!");
		}
		
		
		
		
		
		
		
	public static void main(String[] args) {
		
		Banking xavier = new Banking("Xavier", "X0000001");
		xavier.menu();
	
	}

}
